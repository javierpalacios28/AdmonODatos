f = open("poem.txt", "r")

for line in f:
    print(line, end="")